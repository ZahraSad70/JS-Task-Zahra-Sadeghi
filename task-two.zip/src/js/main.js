const toggle = document.querySelector("#check");
const menu = document.querySelectorAll(".sideBar-item");
toggle.addEventListener("click", (e) => {
    for (let i = 0; i < menu.length; i++) {
        menu[i].classList.toggle("active");
    }

})